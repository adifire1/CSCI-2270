#include "Graph.hpp"
#include <vector>
using namespace std;

/*
 * adds a vertex to the graph
 */
void Graph::addVertex(int n){
    bool found = false;
    for(int i = 0; i < vertices.size(); i++){
        if(vertices[i]->key == n){
            found = true;
        }
    }
    if(found == false){
        vertex * v = new vertex;
        v->key = n;
        vertices.push_back(v);
    }
}

/*
 * adds an edge between two vertices (directed graph)
 */
void Graph::addEdge(int src, int dest){
    for(int i = 0; i < vertices.size(); i++) {
        if(vertices[i]->key == src) {
            for(int j = 0; j < vertices.size(); j++) {
                if(vertices[j]->key == dest && i != j) {
                    adjVertex av;
                    av.v = vertices[j];
                    vertices[i]->adj.push_back(av);
                }
            }
        }
    }
}

/*
 * Complete the following function which checks if vert is a boss vertex
 */
bool Graph::isVertexABoss(vertex *vert) {
    
 // to solve this we use a transversal 
 
 // with transversa l  will go through all the possible adjacent vertexes from our given vertex
 
 // if by the end the bool visited = true for all the vertex then this function will return true
 
 // if by the end the bool visited = false for any vertex then this function will return false
 
 queue <vertex*> coffee;
 coffee.push (vert);
 vertex* p;
 
 while (!coffee.empty()){ // do a search from the designated vertex
     p = coffee.front();
     coffee.pop();
  
     
     
 }
  // after this while loop we can see if any nodes are left as visited= false using a loop
  for (int u = 0 ; u< p->adj.size(); u++){
      
      if (n-> adj[u].v -> -> visited == TRUE){
          continue;
      }
      else { // if any vertex is not visited we must return false
          return false;
      }
      
  }
  
  
 
    
  // if we never have an unvisted node we will return true as vert will be a boss node  
    return true;
}

/*
 * Complete the following function which checks if the graph is a Boss
 */
bool Graph::isGraphABoss() {
    
    // make a loop that puts all of the vertexes through the isAVertexABoss function and if any of them return true, then this function should return true but if the loops is completed and none return true, this function should return false
    
    bool finalAns = false; // start is not a Boss graph
    
    vertex *bob;
    
    for (int i = 0; i< bob-> adj.size(); i++){
        
        // go through the adjacency list and see if any will make the bool true
        
        if (isVertexABoss(adj[i].v) == TRUE){
            finalAns = true;
            break;
        }
        
        
       
    }
    
    return finalAns;
    
    
}
