#include <iostream>
#include "bst.hpp"

using namespace std;

BST::BST() {
	root = NULL;
}

BST::~BST() {
	deleteTree(root);
	root = NULL;
}
void BST::deleteTree(Node* node) {
	if (node != NULL) {
		deleteTree(node->leftChild);
		deleteTree(node->rightChild);
		delete node;
	}
}

/*
** Implement the following function to return the count of comparisons, 
**   you may implement helper functions.
*/
int BST::searchCounter(int target) {
	// your code here!
	
	int counter;
	
	if (target == root-> key){ // if the target is the root we will always return 1
		return 1;
	}
	
	else{
		Node* looka;
		looka = root;
		counter = 1;
		
		while (looka -> key != target){
			
			
			if (looka -> leftChild == NULL && looka -> rightChild == NULL ){ // when we hit a leaf node and have not found our value we must break the loop
				
				break;
			}
			
			if (looka -> key < target){ // if the value of our searcher is less than that of target we must keep looking
				if (looka -> rightChild == NULL){ // value does not exist so break the loop and return the counter
					break;
				}
				looka = looka -> rightChild;
				counter ++; // another comparison
				
				
			}
			
			else if (looka -> key > target){ // if the value of our searcher is more than that of the target we must keep looking
				
				if (looka -> leftChild == NULL){ // value does not exist so break the loop and return the counter
					break;
				}
				looka = looka -> leftChild;
				counter ++; // another comparison
				
			}
			
		
			
			
			
		}
		return counter;
		
		
		
		
	}
	
	
	
	
}
