#include <iostream>

using namespace std;


void merge(int arr[], int loww, int high, int mid)
{
    int i, j, k, c[50];
    i = loww;
    k = loww;
    j = mid + 1;
    while (i <= mid && j <= high)
    {
        if (arr[i] < arr[j])
        {
            c[k] = arr[i];
            k++;
            i++;
        }
        else
        {
            c[k] = arr[j];
            k++;
            j++;
        }
    }
    while (i <= mid)
    {
        c[k] = arr[i];
        k++;
        i++;
    }
    while (j <= high)
    {
        c[k] = arr[j];
        k++;
        j++;
    }
    for (i = loww; i < k; i++)
    {
        arr[i] = c[i];
    }
}



void mergeSort (int arr[], int loww, int high){
    
    if (loww < high){
        int mid;
        mid = (loww + high) /2;
        
        mergeSort(arr, loww, mid);
        mergeSort(arr, mid+1, high);
        
        merge(arr, loww, high, mid);
    }
    
    return;
    
}













int main(){
    
    
    int arrSize = 7;
    int arr[7] = {5, 8, 1, 2, 9, 3, 4};
    int loww = 0;
    int high = 6;
    mergeSort(arr, loww, high);
    
    cout << "Sorted!" << endl;
    
    for (int i = 0; i<7; i++){
        cout << arr[i] << endl;
        
    }
    
    
    return 0;
    
    
}