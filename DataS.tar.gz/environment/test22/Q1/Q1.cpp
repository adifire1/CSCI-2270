/*
CSCI 2270 - Spring 2021
Midterm 1
Question 1 starter code.

*/


#include <iostream>

using namespace std;


void trim (int *&arr, int &len, int target);
    

void testPrint(int *p0, int length);

int main(){
   
    int a_test[] = {3, 2, 5 ,1, 0, 8, 4};
    int test_length = 7;
   
   
    /*
    Test 1
    */
    cout << "\n---------------------\n";
    
    int * a0 = new int[test_length];
    for(int i = 0; i<test_length; i++){
        a0[i] = a_test[i];
    }

    int target = 0; 
    
    /*
        * TODO your function call goes here. It should look like:
       
    */ 
   
    trim(a0, test_length, target); // <== function call

    cout << "Test 1: \n"  << "expected >> 3 2 5 1 " << endl;
    testPrint(a0, test_length);
    delete [] a0;

    return 0;
}




void trim (int *&arr, int &len, int target){
    
    int counter = 0;
     for (int i = 0; i< len; i++){
        if (arr[i] == target){
            break;
            
        }
        else {
            counter ++; // find out how many poitions are going to be filled until we hit a target value
        }
        
     }
     
     int *resizedArr = new int [counter]; // dynamically resize our array
     for (int i = 0; i< counter; i++){
         resizedArr[i] = arr[i]; // fill new array
         
     }
     delete[] arr; // deallocate
     arr = resizedArr;
     

    
    len = counter; 
}


void testPrint(int *p0, int length){
    
    cout << "result   >> ";

    for(int i = 0; i<length; i++){
        cout << p0[i] << " ";
    }
    cout << "\n---------------------\n\n" << endl;
}