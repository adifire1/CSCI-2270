#include <iostream> // predefined header file (defined for you)
using namespace std;

#include "SLL.hpp" // your own header file
// <> vs "" -- compiler looks for the file in the C++ implementation
// vs in the current directory


SLL::SLL(){ // constructor definition
	head = nullptr;
}

SLL::~SLL(){
	Node* crawler;

	while(head!=nullptr){
		crawler = head->next;
		delete head;
		head = crawler;
	}
}


void SLL::displayList(){
	Node* crawler = head;
	while( crawler != nullptr ){
		cout << crawler->key << "->";
		crawler = crawler->next;
	}

	cout << "END" << endl;
}


void SLL::insert(Node* afterMe, char newValue){

	if(head == nullptr){
		// first case: empty list
		// add new node and make head point to it
		head = new Node;
		head->key = newValue;
		head->next = nullptr; // what if we forget this line?
	}
	else if(afterMe == nullptr){
		// This condition implies that the list is not empty, but
		// the caller wants to add node before the head node
		Node* newNode = new Node;
		newNode->key = newValue;
		newNode->next = head;
		head = newNode;
		// at this point, we can test our code for this use case

	}
	else{
		Node* newNode = new Node;
		newNode->key = newValue;
		newNode->next = afterMe->next;
		afterMe->next = newNode;
	}


}

bool SLL::palindrome(){
if (head == NULL){ // empty lists are considered palindromes
	return true;
}

if (head -> next == NULL){ // lists with only one node are considered palindromes
	return true;
}

Node * counter = head;
	int count = 0;
	
	while (counter != NULL){ // to determine the size of the linked list
		count ++;
		counter = counter -> next;
		
		
	}
	count = count -1;
	
	
	int i = 0;
	int j = count;
	bool pali = true;
	
	if (count +1 %2 == 0){ // an even number of letters in the word
		
		while (i<j){ // if we have an even number of letters we keep comparing until i and j pass one another
		if (atIndex(i) != atIndex(j)){
				return false;
			}	
			
			i++;
			j--;
		}
		
		
	}
	
	else {
		while (i != j){ // compare the letters of the first and last, then the next two until we reach a middle letter, this is the case when we have a LL with an odd number of letters
			if (atIndex(i) != atIndex(j)){
				return false;
			}
			
			i++;
			j--;
		}
	}
	return pali;

}

char SLL::atIndex(int i){
	
	Node * temp = head;
	Node * counter = head;
	int count = 0;
	
	while (counter != NULL){ // to determine the size of the linked list
		count ++;
		counter = counter -> next;
		
		
	}
	
	if (i > count-1){ // an invalid index
			return '\0';
	}
	
	
for (int p = 0; p<i; p++ ){ // start at the head of the list and keep moving until you get to the wanted index
	temp = temp -> next; // temp moves one place over every iteration of the loop until we get to index i
	
	
}

return temp-> key; // temp now points to the correct index



}



