#include <iostream>

using namespace std;

void balance(int arrayy[], int n, int i) // n is the size
{
    int largest = i; // Largest starts as the root
    int left = 2 * i + 1; // left = 2*i + 1
    int right = 2 * i + 2; // right = 2*i + 2
 
    // If left child is larger than root
    if (left < n && arrayy[left] > arrayy[largest])
        largest = left;
 
    // If the  right child is larger than largest so far
    if (right < n && arrayy[right] > arrayy[largest])
        largest = right;
 
    // If largest is not root
    if (largest != i) {
        swap(arrayy[i], arrayy[largest]);
 
        
        balance(arr, n, largest);
    }
}

void Sort(int arr[], int n)
{
    for (int i = n / 2 - 1; i >= 0; i--) // make the heap
        balance(arr, n, i);
 
    for (int i = n - 1; i > 0; i--) { // here is when we do the moving and swapping
        // Move the current root to end
        swap(arr[0], arr[i]);
 
        balance(arr, i, 0); // make sure that it is stilla complete tree with greater vals as parents
    }
}