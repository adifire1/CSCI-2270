#include <iostream>
#include <fstream>
#include "MovieTree.hpp"

using namespace std;

LLMovieNode* getLLMovieNode(int r, std::string t, int y, float q)
{
	LLMovieNode* lmn =new LLMovieNode();
	lmn->ranking = r;
	lmn->title=t;
	lmn->year =y;
	lmn->rating =q;
	lmn->next =NULL;
	return lmn;
}

/* ------------------------------------------------------ */
MovieTree::MovieTree()
{
	root = NULL;
}

/* ------------------------------------------------------ */
void inorderTraversalHelper(TreeNode * root) {
		if (root == NULL) {
			return;
		}

		inorderTraversalHelper(root->leftChild);
		cout << root->titleChar << " ";
		inorderTraversalHelper(root->rightChild);
}

void MovieTree::inorderTraversal() {
	inorderTraversalHelper(root);
	cout << endl;
}

/* ------------------------------------------------------ */
TreeNode* searchCharHelper(TreeNode* curr, char key)
{
    if (curr == NULL)
        return curr;
    else if(curr->titleChar == key)
        return curr;
    else if (curr->titleChar > key)
        return searchCharHelper(curr->leftChild, key);
    else
        return searchCharHelper(curr->rightChild, key);
}

TreeNode* MovieTree::searchCharNode(char key)
{
    return searchCharHelper(root, key);
}

/* ------------------------------------------------------ */


TreeNode* checktitle(TreeNode *&root, string title)
{
   if (root == NULL)
   {
       return NULL;
   }

   if (root->titleChar == title[0])
   {
       return root;
   }
   else if (root->titleChar > title[0])
   {
       return checktitle(root->leftChild, title);
   }
   else
   {
       return checktitle(root->rightChild, title);
   }
}

void findNodeTemp(TreeNode*& X, TreeNode*& Y)
{
   if (Y->leftChild != NULL)
   {
       findNodeTemp(X, Y->leftChild);
   }
   else
   {
       X->titleChar = Y->titleChar;
       X->head = Y->head;
       X->parent = X->parent;
       X = Y;
       Y = Y->rightChild;
   }
}

void deleteTree(TreeNode*& t, char titleChar)
{
   if (t == NULL)
   {
       return;
   }
   else
   {
       if (titleChar < t->titleChar)
       {
           deleteTree(t->leftChild, titleChar);
       }
       else if (titleChar > t->titleChar)
       {
           deleteTree(t->rightChild, titleChar);
       }
       else
       {
           TreeNode* X = t;

           if (t->leftChild == NULL)
           {
               if (t->rightChild != NULL)
                   t->rightChild->parent = t->parent;
               t = t->rightChild;

           }
           else if (t->rightChild == NULL)
           {
               if (t->leftChild != NULL)
                   t->leftChild->parent = t->parent;
               t = t->leftChild;
           }
           else
           {

               findNodeTemp(X, t->rightChild);

           }
           delete X;
       }
   }
}

void MovieTree::removeMovieRecord(std::string title)
{
   TreeNode* k = checktitle(root, title);
   if (k != NULL && k->head != NULL)
   {
       if (k->head->title == title)
       {
           LLMovieNode* temp = k->head;
           k->head = k->head->next;
           delete temp;
       }
       else
       {
           LLMovieNode* prev = k->head;
           for (LLMovieNode* h = k->head->next; h != NULL; h = h->next)
           {
               if (h->title == title)
               {
                   LLMovieNode* temp = h;
                   prev->next = h->next;
                   delete temp;
                   break;
               }
               prev = h;
           }
       }

       if (k->head == NULL)
       {
           deleteTree(root, k->titleChar);
       }
       return;
   }
   cout << "Movie: " << title << " not found, cannot delete." << endl;
}