#include <iostream>
using namespace std;

struct Person
{
      int weight ;
     int height;
};

int main()
{
     Person p;
     Person* ptr = &p;
     p.weight=8;
     p.height=6;
     ptr->weight = ptr->weight + 5;
     cout << p.weight;
     return 0;
}