#include <iostream>
#include <fstream>
#include <string>
using namespace std;


int addToArrayAsc(float sortedArray[], int numElements, float newValue){

sortedArray[numElements] = newValue;
int tot;
tot = numElements;
if (numElements!= 0){

while (sortedArray[numElements] < sortedArray[numElements-1]){
    float swap;
    swap = sortedArray[numElements];
    float other;
    other = sortedArray[numElements-1];
    sortedArray[numElements] = other;
    sortedArray[numElements-1] = swap;
    numElements--;

}
}





return tot +1;

}

