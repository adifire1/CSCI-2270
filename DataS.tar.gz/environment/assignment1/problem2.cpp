#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
using namespace std;


struct studentData {
string studentName;
int homework;
int quiz;
int exam;
int recitation;
double average;


};


void addStudentData(studentData students[], string studentName, int homework, int recitation, int quiz, int exam, int length){

students[length].studentName = studentName;
students[length].homework = homework;
students[length].recitation = recitation; 
students[length].quiz = quiz;
students[length].exam = exam;
double avgtot = homework+recitation + quiz + exam;
double avg = avgtot/4;
students[length].average = avg;

}

char calcLetter(double avg){
    char let;
    if (avg >= 90){
        let = 'A';
        return let;
    }
    else if (avg>= 80 && avg <= 89.9){
        
        let = 'B';
        return let;
        
    }
    else if (avg >= 70 && avg <= 79.9){
        let = 'C';
        return let;
    }
    else if (avg >= 60 && avg <= 69.9){
        let = 'D';
        return let;
    }
    else {
        let = 'F';
        return let;
    }
    
    
}

void printList(const studentData students[], int length) {



  for (int i = 0; i < length; i++) {
  char gred = calcLetter(students[i].average);
    cout << students[i].studentName << " earned " << students[i].average << " which is a(n) "<< gred << endl;
  }
}

int main(int argc, char const *argv[]) {
    
// char *openjuan = argv[1];
// char *outjuan = argv[2];
// char lowBound = argv[3][0];
// char upBound = argv[4][0];
    
    studentData student[100];
    ifstream myInRead;
    myInRead.open(argv[1]);
    if myInRead.is_open(){
        string nombre;
        string shomework;
        string temp;
        int hw;
        string squiz;
        int quiz;
        string strExam;
        int exam;
        string srecitation;
        int reci;
        string insertio;
        int tracker = 0;
        while (!myInRead.eof()){
            getline (myInRead, insertio);
            
            
            stringstream convi(insertio);

            getline(convi,nombre,',');
            
            getline(convi,temp,',');
            
            stringstream hwval;
            hwval << temp;
            hwval >> hw;
            
            getline(convi,temp,',');
            stringstream recDat;
            recData << temp;
            recData >> reci;
            
            getline(convi,temp,',');
            stringstream qzdat;
            qzdat << temp;
            qzdat >> quiz;
            
            getline(convi,temp,',');
            stringstream exdat;
            exdat << temp;
            exdat >> exam;
            // insert the data into the array
            addStudentData(student, nommbre, hw, reci, quiz, exam, length);
            tracker++; // increment the length
                        
                        
        }
        
        printList(student, length);
        
        
    }
    
    else {
        cout << << "Failed to open the file." << endl;
    }
}


