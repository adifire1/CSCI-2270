
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int addToArrayAsc(float sortedArray[], int numElements, float newValue){

sortedArray[numElements] = newValue;
int tot;
tot = numElements;

if (numElements != 0){
    
    for (int j = 0; j<=tot-1; j++){
        for (int i = 0; i<=tot-1; i++){
            if (sortedArray[i] > sortedArray[i+1]){
            //cout << "hi" <<endl;
                float swap;
                swap = sortedArray[i];
                //cout << "swap: " <<swap << endl;
                float other;
                other = sortedArray[numElements-1];
                //cout << "other: " <<other << endl;
                sortedArray[i] = sortedArray[i+1];
                //cout << "hello" << endl;
                sortedArray[i+1] = swap;
                //numElements--;
            }
        }
    }

}
//out << sortedArray[0] << endl;
return tot +1;

}

// I have already taken this class once and this is the code that I orignally and authentically wrote
//Also used a bubble sort my tutor taught me

int main(int argc, char const *argv[]) {
    
  float myArr[100];
  string temp;
  int tracker = 0;
  ifstream myFalafel;
  myFalafel.open(argv[1]);
  if (myFalafel.is_open()){
  while (!myFalafel.eof()) {
    getline(myFalafel, temp);
  
    float newe;
    newe = stof(temp);
//    cout << newe << endl;
    addToArrayAsc(myArr, tracker, newe);
      tracker++;
 //   cout << myArr[0] << endl;
   for (int p = 0; p<tracker; p++){
        if (p<tracker-1){
        cout << myArr[p] << ",";
        }
        else {
            cout << myArr[p];
        }
    }
    cout << endl;
  }
  return 0;
  }
  else {
      cout << "Failed to open the file." << endl;
  }
}

//again I already have taken this class and this is the code that I wrote on my own