#include <iostream>
#include "StackCalculator.hpp"


using namespace std;
/*
 * Purpose: Determine whether some user input string is a
 *          valid floating point number
 * @param none
 * @return true if the string s is a number
 */
bool isNumber(string s)
{
    if(s.size() == 1 && s == "-")
      return false;

    else if(s.size() > 1 && s[0] == '-')
      s = s.substr(1);

    bool point = false;
    for(int i = 0; i < s.size(); i++){
      if(!isdigit(s[i]) && s[i] != '.')
        return false;
      if(s[i]=='.' and !point) point = true;
      else if(s[i]=='.' and point) return false;
    }

    return true;
}

StackCalculator::StackCalculator()
{
  stackHead = NULL;
}

StackCalculator::~StackCalculator()
{
  Operand* temp1 = stackHead;
   while(temp1 != NULL) {
      delete temp1;
      temp1 = temp1 ->next;
  }
  stackHead = NULL;
}

bool StackCalculator::isEmpty()
{
	
	if (stackHead == NULL) {
    return true;
  }
  return false;
  
  
}

void StackCalculator::push(float number)
{
  Operand* temp1 = new Operand;
  temp1->number = number;
  temp1->next = stackHead;
  stackHead = temp1;
}

void StackCalculator::pop()
{
	 if (!isEmpty()) {
    Operand* temp1 = new Operand;
    temp1 = stackHead;
    stackHead = stackHead->next;
    delete temp1;
  } else {
    cout << "Stack empty, cannot pop an item." << endl;
  }
}

Operand* StackCalculator::peek()
{
	 if (!isEmpty()) {
      return stackHead;
  } 
    else {
      cout << "Stack empty, cannot peek." << endl;
      return NULL;
  }
}


bool StackCalculator:: evaluate(string* s, int size)
{
 
   if(isNumber(s[size-1]) == false && (s[size-1] == "+" || s[size-1] == "*") ){
    
      cout <<"err: not enough operands";
      return false;
    }
    
    else if (isNumber(s[size-1]) == false && (s[size-1] != "+" || s[size-1] != "*")){
      cout << "err: invalid operation";
      return false;
      
    }
 
    for (int i = size-1; i>=0; i--){
    
    
      if (isNumber(s[i]) == true){
        float pv = stof(s[i]);
        //cout << "pv: " <<pv <<endl;
        push(pv);
      }
      
    
 
      
      else if (isNumber(s[i]) != true && s[i] == "+") {
      
      float ad1 = stackHead -> number;
      float ad2 = stackHead -> next -> number;
      //cout << "ad1: " <<ad1 << endl;
      //cout << "ad2: " <<ad2 << endl;
       pop();
       pop();
       push (ad1 + ad2);
      }
      
      else if (s[i] == "*"){
        
      float m1 = stackHead -> number;
      float m2 = stackHead -> next -> number;
        pop();
        pop();
        push (m1 * m2);
        
      }
      
      else {
        cout << "err: invalid operation";
        return false;
      }
      
      
      
      
    }
    
    
    
  return true;
 




}

