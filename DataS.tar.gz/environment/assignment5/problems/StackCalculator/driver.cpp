#include<iostream>
#include<cmath>
#include<iomanip>
#include "StackCalculator.hpp"

using namespace std;



int main()
{
  // stack to hold the operands
  StackCalculator stack;

  int numElement = 0;
  string* inparr = new string[50];

  // enter a number
  string number;
  cout << "Enter the operators and operands ('+', '*') in a prefix format" << endl;


  while(true)
  {
    cout << "#> ";
    getline(cin, number);
    
    if (number!= "="){
      inparr[numElement] = number;
      numElement ++;
      
    }
    else{
      break;
    }
  }
  
  

  
  if (numElement == 0){
    cout << "No operands: Nothing to evaluate" << endl;
  }
  
  
  else {
    if(stack.evaluate(inparr, numElement)){
    // get the top element of stack
        float result = stack.getStackHead()->number;
        stack.pop();
    if(stack.isEmpty()){ // stack empty, valid expression
    cout<<"Result= "<<result;
    }
    else{ // stack not empty, invalid expression
    cout<<"Invalid expression"<<endl;
    }
    }
    
    
  }
  
  
    

 delete[] inparr;
  return 0;
}
