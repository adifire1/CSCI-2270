bool isIgnoreWord(string word, string ignoreWords[])
{

bool b1;
b1 = false;

for (int i = 0; i<50; i++){
    if (ignoreWords[i] == word){
        return true;
    }
    
    else if (ignoreWords[i]!= word){
        continue;
    }
    
    
    
}
return false;

}

void getIgnoreWords(const char *ignoreWordFileName, string ignoreWords[])
{

ifstream source;
source.open(ignoreWordFileName);
 if (source.is_open())
  {
  string x;
  int i = 0;
  while (source >> x){
      ignoreWords[i] = x;
      i++;
      
  }
  
  
  }
  
  else{
      cout << "Failed to open "<< ignoreWordFileName << endl;
  }





}

int getTotalNumberNonIgnoreWords(wordRecord distinctWords[], int length)
{

int total;
total = 0;
    for (int i = 0; i<length; i++){
        total = total + distinctWords[i].count; 
        
    }
    return total;
    
}

void sortArray(wordRecord distinctWords[], int length)
{
    
    
    for (int i = 0; i< length-1; i++){
        
        for (int j= i+1; j<length; j++){
            int comp1;
            int comp2;
            comp1 = distinctWords[i].count;
            comp2 = distinctWords[j].count;
            
            if (comp1 < comp2){ // comparing the value and the one after it
                wordRecord swap;
                swap = distinctWords[i];
                distinctWords[i] = distinctWords[j];
                distinctWords[j] = swap;
                
                
            }
            
            
        }
        
        
        
        
    }
    
    
    
    
}



void printTenFromN(wordRecord distinctWords[], int N, int totalNumWords)
{
     
   for (int i = N; i<N+ 10; i++){
    float answer = 0;
       answer = (float)distinctWords[i].count/totalNumWords;
       cout << setprecision(5) << fixed << answer << " - " << distinctWords[i].word << endl;
   } 
    
    
    
    
    
}
