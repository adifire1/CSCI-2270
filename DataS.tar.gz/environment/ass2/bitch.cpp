#include <iostream>
using namespace std;

int main(){
    int a = 5; int b = 12;
    int *pa=&a; int *pb=&b; int *pc;
    pc = pb;
    pb = pa;
    *pc = b+5;
    a = *pb +4;
    cout << *pa << "," << *pb << "," << *pc << b<< endl;
    
    
    
    
}