
#include <iostream>

#include <string>

#include <fstream>

#include <iomanip>

#include <cstdlib>

using namespace std;

struct wordRecord{
    string word;
    int count;
};

const int ignCount = 50;

bool isIgnoreWord(string word, string ignoreWords[])
{

bool b1;
b1 = false;

for (int i = 0; i<ignCount; i++){
    if (ignoreWords[i] == word){
        return true;
    }
    
    else if (ignoreWords[i]!= word){
        continue;
    }
    
    
    
}
return false;

}

void getIgnoreWords(const char *ignoreWordFileName, string ignoreWords[])
{

ifstream source;
source.open(ignoreWordFileName);
 if (source.is_open())
  {
  string x;
  int i = 0;
  while (source >> x){
      ignoreWords[i] = x;
      i++;
      
  }
  
  
  }
  
  else{
      cout << "Failed to open "<< ignoreWordFileName << endl;
  }





}

int getTotalNumberNonIgnoreWords(wordRecord distinctWords[], int length)
{

int total;
total = 0;
    for (int i = 0; i<length; i++){
        total = total + distinctWords[i].count; 
        
    }
    return total;
    
}

void sortArray(wordRecord distinctWords[], int length)
{
    
    
    for (int i = 0; i< length-1; i++){
        
        for (int j= i+1; j<length; j++){
            int comp1;
            int comp2;
            comp1 = distinctWords[i].count;
            comp2 = distinctWords[j].count;
            
            if (comp1 < comp2){ 
                wordRecord swap;
                swap = distinctWords[i];
                distinctWords[i] = distinctWords[j];
                distinctWords[j] = swap;
                
                
            }
            
            
        }
        
        
        
        
    }
    
    
    
    
}



void printTenFromN(wordRecord distinctWords[], int N, int totalNumWords)
{
     float vals[10];
     int x = 0;
     string names[10];
   for (int i = N; i<N+ 10; i++){
      vals[x] = (float)distinctWords[i].count/totalNumWords;
      names[x] = distinctWords[i].word;
      x++;
   } 
     
     for (int c = 0; c<10; c++){
     for (int t = 0; t<10; t++){
         if (vals[t]== vals[t+1]){
             if (names[t] > names [t+1]){
            string temp = names[t];
            names[t] = names[t+1];
            names[t+1] = temp;
             }
             
             
             
         }
         
     }
     }
     
     for (int p = 0; p<10; p++){
         cout << setprecision(5) << fixed << vals[p];
         cout << " - " <<names[p] << endl;
     }
    
    
    
    
}

int main(int argc, char*argv[]){
    //cout << "hi";
    ifstream inputIgnore;
    ifstream inputText;
     string ignoreWords[50];
    inputText.open(argv[2]);
    getIgnoreWords(argv[3], ignoreWords);
     int totalWordsRead = 0;
    int starterLength = 100;
    
    if (inputText.is_open()){
      
      bool read;
      int doubled = 0;
      wordRecord *solo;
      solo = new wordRecord[starterLength];
      string wordi;
      int repeatt;
      while (inputText >> wordi){
           repeatt = 0;
          if (!isIgnoreWord(wordi, ignoreWords)){
              for (int i = 0; i<totalWordsRead; i++){
                   
                  if (wordi == solo[i].word){
                      solo[i].count = solo[i].count + 1;
                      repeatt = 1;
                      break;
                       
                  }
                  else {
                      repeatt = 0;
                  }
                   
              }
               
               
              if (repeatt == 0){ // distinct word
                  if (totalWordsRead == starterLength){ 
                   
                  wordRecord *temp1 = new wordRecord[starterLength*2];
                  for (int j = 0; j<starterLength; j++){
                      temp1[j] = solo[j];
                  }
                  delete[] solo;
                  solo = temp1;
                  doubled ++;
                  starterLength = starterLength*2;
                  }
                  
               
                  solo[totalWordsRead].word = wordi;
                  solo[totalWordsRead].count = 1;
                totalWordsRead ++;
                  
               }
               
               
           }
           
           
           
           
           
      }
       
        
        
        cout << "Array doubled: " << doubled << endl;
        cout << "Distinct non-common words: " << totalWordsRead << endl;
        int numba;
        int theN = atoi (argv[1]);
        numba = getTotalNumberNonIgnoreWords(solo, totalWordsRead);
        cout << "Total non-common words: " << numba << endl;
        cout << "Probability of next 10 words from rank "<< theN << endl;
        cout << "---------------------------------------" << endl;
        
        
        
        sortArray(solo, totalWordsRead);
        printTenFromN(solo, theN , numba);
        
        
      
        
        
        
    }
    
    
}
