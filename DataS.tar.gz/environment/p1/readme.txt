Aditya Kelshiker

My program allows the user to view a menu and select from a group of options, they can add a file, remove a file, commit a file(s), checkout to A GIT repository and quit.

The options all meet the designations as specified in the write up for the project and utilizes various data structures such as a linked list, doubly linked list and has various functions to help the implementation

