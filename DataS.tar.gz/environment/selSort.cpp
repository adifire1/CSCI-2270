#include <iostream>

using namespace std;

int main(){
    
   int arr[5] = {3, 5, 6, 1, 4}; //unsorted array
   int n = 5;
   int smallest; // the smallest element index
   int i; // left index
   int j;
   int tempo;
   
   for (i = 0; i<n-2; i++){
       smallest = i;
       
       for (j = i+1; j<n; j++){ // j is one to the right of i and is used for looping
           
           if (arr[j]< arr[smallest]){
               smallest = j;
           }
           
           
       }
       
       tempo = arr[i];
       arr[i] = arr[smallest];
       arr[smallest] = tempo;
       
   }
   
   
   cout << "Sorting completed!" << endl;
   
   for (int p = 0; p<n; p++){
       cout << arr[p] << endl;
       
       
       
   }

    
    
}