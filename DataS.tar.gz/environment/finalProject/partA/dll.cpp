#include <iostream>
#include "dll.hpp"
#include <string>

using namespace std;


void DLL :: printList(){
    
if (head == NULL){
    
    cout << "List is empty" << endl;
    
}   

else {
    
    struct Node* mover;
   mover = head;
   while(mover != NULL) {
      cout<< mover->key << " --> ";
      mover = mover ->next;
   }
    
    cout << endl;
}

    
}

void DLL :: insert(int value){
    
    struct Node* newb = new Node;
   newb->key = value;
   newb->prev = NULL;
   newb->next = head;
   if(head != NULL)
   head->prev = newb ;
   head = newb;
    
}


void DLL :: search(){
    cout << "Enter what you want to search for: " << endl;
    int count = 0;
    int enter;
    cin >> enter;
    struct Node * lookie = head;
    while (lookie != NULL){
        if (lookie -> key == enter){
            cout << "Your search was found at location: " << count+1 << endl;
            
        }
        
        lookie = lookie -> next;
        count ++;
        
    }
    
    
    
}