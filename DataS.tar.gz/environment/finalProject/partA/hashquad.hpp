#include <iostream>

using namespace std;

struct HashTable
{
    int size;
    HashNode *table;
};


