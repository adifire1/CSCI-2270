#include <iostream>
#include <fstream>
#include "hashdriver.cpp"
#include <string>
using namespace std;

int main(){
    int main(){
    
     ifstream source;
     int testData [10000];
    source.open("dataSetA2.csv");
    int p = 0;
    while (source.good()){
        string raw;
        getline (source, raw, ',');
        testData[p] = stoi (raw); // save all values into this array
        p++;
    }
    
    
    
}