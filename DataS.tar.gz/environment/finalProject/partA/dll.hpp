#include <iostream>
using namespace std;


struct Node {
    
    
    int key;
    Node * next;
    Node * prev;
    
};

class DLL {
    
    
    private:
    Node * head;
    
    public:
    DLL(){
        head = NULL;
    } 
    void printList();
    void insert(int value);
    void search();
};
