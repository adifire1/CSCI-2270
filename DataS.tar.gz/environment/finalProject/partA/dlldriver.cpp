#include <iostream>
#include <fstream>
#include "dll.cpp"
#include <string>
#include <chrono>
using namespace std;

int main(){
    
     ifstream source;
     int testData [10000];
    source.open("dataSetA2.csv");
    int p = 0;
    while (source.good()){
        string raw;
        getline (source, raw, ',');
        testData[p] = stoi (raw); // save all values into this array
        p++;
    }
    
    DLL BTS;
    
 int count = 0;
 for (int i = 0; i< 100; i++){
     int place = count;
     
     for (int j = place; j<place + 100; j++){
         if (j<10000){
             auto start = chrono::steady_clock::now(); 
             BTS.insert(testData[j]);
             count++;
         }
         
     }
     
 }
    
  BTS.search();
    
}
    

// i want to insert 100 elements 100 times each by 100 more