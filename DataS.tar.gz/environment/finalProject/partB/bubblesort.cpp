#include "bubblesort.hpp"
#include <iostream>

using namespace std;


void bubbleSort :: insertValue(int value, int arr[]){
     int i = 0;
    while(1){
   
   
    
    if (arr[i] != 0){
    //cout << "spot " << i << " full" << endl;
    i++;
    }
    else {
        arr[i] = value;
        cout << "Inserted successfully" << endl;
        return;
    }
        
        
        
    }
    
    
}


void bubbleSort :: displayElements(int arr[], int size){
    // int i = 0;
    // while (1){
        
    //     if (arr[i]!= 0){
    //     cout << arr[i] << endl;
    //     i++;
    //     }
    //     else {
    //       cout << "All elements displayed" << endl;
    //       return;
    //     }
        
    // }
    
    for (int i = 0; i<size; i++){
        
        
        cout << arr[i] << endl;
    }
    cout << "All elements displayed" << endl;
    
}


void bubbleSort :: searchValue(int arr[], int size){
    cout << "Enter value to be searched: " << endl;
    int valuese;
    int i = 0;
    cin >> valuese;

    
    for (int i = 0; i< size; i++){
        
         if (arr[i]!= valuese){
            i++;
           // cout << i << endl;
            
        }
        
        if (arr[i] == valuese) {
            cout << "This item can be found at index: "<< i << endl;
            return;
        }
        
        else {
            cout << "This item does not exist" << endl;
        }
        
    }
    
    
}

void bubbleSort :: sortIt(int arr[], int size){
    
    int temp;
    for (int i = 0; i < size-1; i++)
        {
        
        for (int j = 0; j<size-1; j++){
            
            if (arr[j] > arr[j+1]){
                
                temp = arr[j];
                arr[j] = arr[j+1];
                arr[j+1] = temp;
                
            }
            
        }
        
        
         }
    
    
    cout << "Sorted" << endl;
    
}

