#include <iostream>
#include <fstream>
#include "heapsort.cpp"
#include <string>
using namespace std;



int main(){
    
    ifstream source;
     int testData [10000];
    source.open("dataSetA.csv");
    int p = 0;
    while (source.good()){
        string raw;
        getline (source, raw, ',');
        testData[p] = stoi (raw);
        p++;
    }

    int size = 100;
    
    