#include <iostream>
//#include "bubblesort.cpp"

using namespace std;

class bubbleSort
{
    
    
    
    public:
    void insertValue (int value, int arr[]);
    void searchValue (int arr[], int size);
    void displayElements(int arr[], int size);
    void sortIt(int arr[], int size);
    
    
    
    
};

