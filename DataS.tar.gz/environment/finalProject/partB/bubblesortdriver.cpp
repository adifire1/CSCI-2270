#include <iostream>
#include "bubblesort.cpp"
//#include "bubblesort.hpp"
#include <string>
#include <fstream>
#include <chrono>

using namespace std;



int main(){
    
    ifstream source;
    //string testers[10000];
     int testData [10000];
    source.open("dataSetA.csv");
    int p = 0;
    while (source.good()){
        string raw;
        getline (source, raw, ',');
        testData[p] = stoi (raw);
        p++;
    }
    
   // cout << testData[4];
    
    
    
 
   // testData [0] = 69;
    // testData [9999] = 83;
    // testData [99998] = 420;
    int size = 100;
   
    
    for (int i = 0; i<100; i++){
        int * arrvals = new int[size];
          bubbleSort crab;
        //cout << size << endl;
        for (int j = 0; j<size; j++){
           
            arrvals[j] = testData[j];
        }
       
        
         //cout << size << endl;
           //auto start = std::chrono::steady_clock::now();
        crab.sortIt(arrvals, size);
            //auto end = std::chrono::steady_clock::now();
            //double elapsed_seconds = end-start;
           // cout << "Time taken: " << elapsed_seconds.count() << "s";
         //cout << "Run: "<< i << " arrval 0: " << arrvals[0] << endl;
        size = size +100;
       
        delete [] arrvals;
    }
    

    
    
    //bubbleSort crab;
//     crab.insertValue(8, arrvals);
//   // cout << "This is array in the main at position 0: " << arrvals[0] << endl;
//     crab.insertValue(4, arrvals);
//     //cout << "This is array in the main at position 1: " << arrvals[1] << endl;
//     crab.insertValue(6, arrvals); 
//     crab.displayElements(arrvals, 3);
//     crab.searchValue(arrvals, 3);
//     //cout << arrvals[1] << endl;
//     // crab.sortIt(arrvals, 3);
//     // crab.displayElements(arrvals, 3);
    
    return 0;
    
}