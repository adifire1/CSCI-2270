struct CUBuilding{
  string name;
  string message;
  int numberMessages;
  CUBuilding *next;
  int totalRoom;
};

bool append(string* &str_arr, string s, int &numEntries, int & arraySize){
   bool done;
done = false;
   if(numEntries == arraySize){ // same doubling algorithm from assignment 2
    
       string* dubArr = new string[arraySize*2];
       for(int i=0;i<numEntries;i++){ // copy old array to new
           dubArr[i] = str_arr[i];
       }
       delete [] str_arr;
    arraySize = arraySize *2;
       str_arr = dubArr;
       done = true;
   }
 
   str_arr[numEntries] = s;
     numEntries++;
   return done;
}

void CUBuildingNetwork::loadDefaultSetup() {


    addBuildingInfo(NULL, "FLMG", 2);
     addBuildingInfo(head, "DLC", 10);
      addBuildingInfo(head->next, "ECOT", 6);
     addBuildingInfo(head->next->next, "CASE", 5);
      addBuildingInfo(head->next ->next -> next, "AERO", 4);
      addBuildingInfo(head->next ->next -> next-> next, "RGNT", 9);
}




CUBuilding* CUBuildingNetwork::searchForBuilding(string buildingName)
{

    
    CUBuilding *starter = head;
    while (starter!= NULL){
        
        if (starter -> name == buildingName){
            return starter;
            
        } 
        starter = starter-> next;
        
    }
    
    
    
}


void CUBuildingNetwork::addBuildingInfo(CUBuilding* previous, string buildingName, int numOfroom)
{
 
// CUBuilding *starter = head;
 
if (previous == NULL){ 
    
    if (head == NULL){ // empty list
        
        head = new CUBuilding;
        head -> name = buildingName;
        head -> totalRoom = numOfroom;
        head -> next = NULL;
        
        
    }
    
    else {
        
        CUBuilding *insertio = new CUBuilding;
        insertio -> name = buildingName;
        insertio -> totalRoom = numOfroom;
        insertio -> next = head;
        head = insertio;
        
    }
    
    cout << "adding: " << buildingName << " (HEAD)" << endl;
    return;

} 

else {
    CUBuilding *insertio2 = new CUBuilding;
    insertio2 -> name = buildingName;
    insertio2 -> totalRoom = numOfroom;
    insertio2 -> next = previous-> next;
    previous -> next = insertio2;
    
}
 
  cout << "adding: " << buildingName << " (prev: " << previous->name <<  ")"<< endl;  
    
}

// I have already taken this class once and this is the code I used before

void CUBuildingNetwork::transmitRoomInfo(string receiver)
{
    
    CUBuilding* transverse = head;
    
    if (head == NULL){
        cout << "Empty List" << endl;
        return;
    }
    
    
    CUBuilding * checker = head;
    bool exists;
    exists = false;
    while (checker != NULL){
    
    if (checker -> name == receiver){
    
    exists = true;
    }
    checker = checker -> next;
    }
    
    
    if (exists == false){
    cout << "Building not found" << endl;
    return;
    }
    
    while (transverse != NULL){
        string name = transverse -> name;
        int available = transverse -> totalRoom;
        string conv = to_string (available);
        string insert = "available room at " + name + " is " + conv; 
        transverse -> message = insert;
        transverse -> numberMessages = transverse -> numberMessages+1;
        cout << transverse->name << " [# messages received: " << transverse->numberMessages <<"] received: " << transverse->message << endl;

        
        
        if (transverse-> name == receiver){
            
            return;
        }
        
        
        transverse = transverse -> next;
        
    }
    
    
}

void CUBuildingNetwork::printNetwork()
{
    
    if (head == NULL){
        cout << "nothing in path" << endl;
        return;
    }
    
    CUBuilding * navi = head;
    
    while (navi!= NULL){
        cout << navi -> name << endl;
        
    }
    
    return;
}


void CUBuildingNetwork::deleteCUBuilding(string buildingName) {
   
   CUBuilding *searcher = head;
   CUBuilding *follow = head -> next;
   CUBuilding *first = head;
   
   
   if (searcher -> name == buildingName){ // if we need to delete the head
       
       head = follow;
       delete searcher;
       return;
       
   }
   
   while (follow != NULL && follow-> name != buildingName){
      
      follow = follow -> next;
      searcher = searcher -> next;
      
   }
   
   if (follow == NULL){
       cout << "Building does not exist." << endl;
       return;
   }
   
   searcher -> next = follow -> next;
   delete follow;
   
    
    
    return;
}

void CUBuildingNetwork::deleteEntireNetwork()
{

CUBuilding * deleter = head;
CUBuilding * yolo = NULL;
CUBuilding * yeet = head;

while (yeet != NULL){
    
    cout << "deleting: " << yeet -> name << endl;
    yeet = yeet -> next;
    
}

if (deleter == NULL){ // empty list
  
  return;
    
}

while (deleter != NULL){
    
    yolo = deleter -> next;
    delete (deleter);
    
    deleter = yolo;
}

head = NULL;

cout << "Deleted network" << endl;
return;

}

bool CUBuildingNetwork::detectLoop() {
    
    CUBuilding * sherlock = head;
    CUBuilding * watson = head -> next;
    bool answer;
    while (sherlock != NULL && watson != NULL && watson -> next != NULL){
        sherlock = sherlock -> next;
        watson = watson -> next -> next;
        if (sherlock == watson){
            answer = true;
            return answer;
            
        }
        
        
    }
    
    answer = false;
    return answer;
    
    
    
}

CUBuilding* CUBuildingNetwork::createLoop(string buildingName) {
    // TODO: Complete this function
    // NOTE: Following functions are already included and available for use
    //       addBuildingInfo, loadDefaultSetup, searchForBuilding, printNetwork
    
    
    CUBuilding * looper = head;
    CUBuilding * replacer = searchForBuilding(buildingName);
    
    
    while (looper->next != NULL){
        
        looper = looper -> next;
    }
    
    looper -> next = replacer;
    return looper; 
    
}

void CUBuildingNetwork::readjustNetwork(int start_index, int end_index)
{
    // TODO: Complete this function
    // NOTE: Following functions are already included and available for use
    //       addBuildingInfo, loadDefaultSetup, searchForBuilding, printNetwork
    
    if (head == NULL){
        
        cout << "Linked List is Empty" << endl;
        return;
    }
    
    if (start_index > end_index){
        cout << "Invalid indices" << endl;
        return;
        
    }
    
    CUBuilding * read = head;
    CUBuilding *sb = head;
    CUBuilding * start = head ; // node of the start index
    CUBuilding * eb = head ;
    CUBuilding * end = head; // node of the end index
    CUBuilding * ednext;
    //sb = start -> next;
    int counter = 0;
    //eb = end -> next;
    
    
    CUBuilding * count = head;
    
    while (count != NULL){
        count = count -> next;
        counter ++;
        
    }
    //cout << "Count: " << counter << endl;
    
    if (end_index >= counter || start_index<0){
        cout << "Invalid end index" << endl;
        return;
        
    }
    
    for (int i = 0; i<start_index; i++){ // start points to our start index
    start = start -> next;
    
    }
    
    for (int p = 1; p<start_index; p++){ // sb points to node before start index
        sb = sb -> next;
        
    }
    
    for (int j = 0; j< end_index; j++){ // end points to end index
    end = end -> next;
    }
    
    for (int b = 1; b<end_index; b++){ // eb points to one before end index
        
        eb = eb -> next;
    }
    
    ednext = end -> next; 
    
    CUBuilding * last = head;
    while ( last-> next != NULL){
        
        last = last -> next;
        
        
    }
    
    
    if (start_index == 0){
        
         head = ednext;
        
        if (ednext-> next == NULL){
        ednext -> next = start;
        }
        
        //sb -> next 
        
         last-> next = start; 
        
        end -> next = NULL;
       
        return;
    }
    
    
    else if (start_index == end_index){
        //cout <<"sb: " <<sb-> name << endl;
        sb -> next = ednext;
        last -> next = end;
        end -> next = NULL;
        
        
        
    }
    
    else if (start_index == end_index && end_index = counter){
        
        return;
        
    }
    
    else {
        
        sb -> next = ednext;
        ednext -> next = start;
        end -> next = NULL;
        
        
        
    }
  
}