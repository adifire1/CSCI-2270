#include <iostream>

using namespace std;

void swap(int* a, int* b)  
{  
    int swappa = *a;  
    *a = *b;  
    *b = swappa;  
}  

int partition(int *arr, int start, int end){
    int pivot = arr[end];
    int partIndex = start;
    for (int i = start; i<end; i++){
        if (arr[i] <= pivot){
            swap(arr[i], arr[partIndex]);
            partIndex ++;
            
        }
        
        
    }
    swap(arr[partIndex], arr[end]);
    return partIndex;
    
    
}

void quickSort (int *arr, int start, int end){
    if (start < end){
        int partIndex = partition(arr, start, end);
        quickSort(arr, start, partIndex-1);
        quickSort(arr, partIndex+1, end);
    }
    
}


int main(){
    
   int arr[5] = {3, 5, 6, 1, 4}; //unsorted array
   int start = 0;
   int end = 6;
  quickSort(arr, start, end);
  cout << "Sorting completed!" << endl;
   
   for (int p = 0; p<6; p++){
       cout << arr[p] << endl;
       
       
       
   }

    
    
}