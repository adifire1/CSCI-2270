#include <iostream>

using namespace std;

struct Node {
  int key;
  Node *next;
};


int main(){
A->next = B;
B->next = A->next;

Node* temp = head;

while(temp->next != NULL){
    cout<< temp->key <<" -> ";
    temp = temp->next;
}

cout<<temp->key<<endl;

}