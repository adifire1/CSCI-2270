#include <iostream>
#include <fstream>
#include "MovieTree.hpp"

using namespace std;

LLMovieNode* getLLMovieNode(int r, std::string t, int y, float q) // was given
{
	LLMovieNode* lmn =new LLMovieNode();
	lmn->ranking = r;
	lmn->title=t;
	lmn->year =y;
	lmn->rating =q;
	lmn->next =NULL;
	return lmn;
}

/* ------------------------------------------------------ */
MovieTree::MovieTree() // constructor
{
	root = NULL;
}
void deleteAllTree(TreeNode *&t)
{
   if (t == NULL) // case where the tree is empty so we can just return
   {
       return;
   }
   

   deleteAllTree(t->leftChild); // recurse down left side of tree and deallocate associated memory
   deleteAllTree(t->rightChild); // recurse down right side of tree and deallocate associated memory
                                //delete the entire list
   LLMovieNode* head = t->head;
   while (head != NULL)
   {
       LLMovieNode* temp = head; // keep on moving our pointers and use temp to be our deleter
       head = head->next; // next node is head
       delete temp;
   }
   delete t;
}

MovieTree::~MovieTree()
{
   deleteAllTree(root); // start at the root and use the helper function
}
/* ------------------------------------------------------ */
void inorderTraversalHelper(TreeNode * root) {
		if (root == NULL) {
			return;
		}

		inorderTraversalHelper(root->leftChild);
		cout << root->titleChar << " ";
		inorderTraversalHelper(root->rightChild);
}

void MovieTree::inorderTraversal() {
	inorderTraversalHelper(root);
	cout << endl;
}

/* ------------------------------------------------------ */
TreeNode* searchCharHelper(TreeNode* curr, char key) // was given
{
    if (curr == NULL)
        return curr;
    else if(curr->titleChar == key)
        return curr;
    else if (curr->titleChar > key)
        return searchCharHelper(curr->leftChild, key);
    else
        return searchCharHelper(curr->rightChild, key);
}

TreeNode* MovieTree::searchCharNode(char key) // was given
{
    return searchCharHelper(root, key);
}

void InorderMovie(TreeNode* root){
    if(root == NULL) // empty tree
        return;
    InorderMovie(root -> leftChild); // recurse to the left child 
    LLMovieNode *ptr = root -> head;
    cout << "Movies starting with letter: " << root -> titleChar << endl; // title
    while(ptr != NULL){
        cout << " >> " << ptr -> title << " " << ptr -> rating << endl; // rating
        ptr = ptr -> next;
    }
    InorderMovie(root -> rightChild); // recurse to the right child
}

void MovieTree :: showMovieCollection(){
    InorderMovie(root); // our movie collection is just an in-order transversal from the root
}

LLMovieNode *insertInLinkedList(LLMovieNode *root, LLMovieNode *newnode){ // function to insert a movie into the linked list
    if(root == NULL || root -> title >= newnode -> title){
        newnode -> next = root;
        root = newnode; // we are inserting the
    }
    else{ // now we find the correct spot in the linked list and insert
        LLMovieNode *ptr = root;
        while(ptr -> next != NULL && ptr -> next -> title < newnode -> title){
            ptr = ptr -> next;
        }
        newnode -> next = ptr -> next;
        ptr -> next = newnode;
    }
    return root;
}

TreeNode *insertHelper(TreeNode *root, LLMovieNode *newnode, char key, TreeNode *parent){
    if(root == NULL){ // empty tree case
        root = new TreeNode();
        root -> head = insertInLinkedList(root -> head, newnode);
        root -> titleChar = key;
        root -> parent = parent;
    }
    else if(key < root -> titleChar){ // going alphabetically, keep recursing until we find where we need
        root -> leftChild = insertHelper(root -> leftChild, newnode, key, root);
    }
    else if(key > root -> titleChar){ // going alphabetically, keep recursing until we find where we need
        root -> rightChild = insertHelper(root -> rightChild, newnode, key, root);
    }
    else{ // we have found the correct place so it is time to insert
        root -> head = insertInLinkedList(root -> head, newnode);
    }
    return root;
}

void MovieTree :: insertMovie(int ranking, std::string title, int year, float rating){ 
    LLMovieNode *newnode = getLLMovieNode(ranking, title, year, rating); // make a new node with the designated data
    root = insertHelper(root, newnode, title[0], NULL); // helper function to insert
}




void MovieTree::removeMovieRecord(string title){
    
    TreeNode * searcha = searchCharHelper(root, title[0]);
    if (searcha == NULL){ // the searcha can't find the movie so does not exist in library
        cout << "Movie not found." << endl;
        return;
    }
    // declare and initialie our searchers
    LLMovieNode * marker = searcha -> head;
    LLMovieNode * temp1 = marker;
    
    if (marker != NULL && marker-> title == title){
        searcha -> head = marker -> next; // we found the title of the movie
        delete marker; // free the memory
        return;
    }
    while(marker != NULL && marker -> title != title){ // we keep going until we find the title
        temp1 = marker;
        marker = marker -> next;
    }
    
    if (marker == NULL){ // if we keep looking and merker is still NULL, the movie cannot be found
        cout << "Movie not found" << endl;
    }
    temp1 -> next = marker -> next;
    delete marker; // by the end we have found it so we must deallocate
    
    
    
    
    
}

void MovieTree::leftRotation(TreeNode* curr) // a left rotation makes the right child of a node the parent and the parent node becomes the left child

{
   TreeNode* right = curr->rightChild;

   if (curr->titleChar == root->titleChar)
   {
       curr->rightChild = right->leftChild;
       right->leftChild = curr;
       right->parent = NULL;
       curr->parent = right;
       if (curr->rightChild != NULL)
       {
           curr->rightChild->parent = curr;
       }
       root = right;
       return;
   }

   if (curr->parent->rightChild->titleChar == curr->titleChar)
   {
       curr->parent->rightChild = right;
   }
   else
   {
       curr->parent->leftChild = right;
   }
   right->parent = curr->parent;
   curr->parent = right;

   curr->rightChild = right->leftChild;
   if (right->leftChild != NULL)
   {
       right->leftChild->parent = curr;
   }
   right->leftChild = curr;
}


/* ------------------------------------------------------ */