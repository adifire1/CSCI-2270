#include "MovieTree.hpp"
#include <iostream>
#include <string>
#include<fstream>
#include <sstream>

using namespace std;

// MovieNode: node struct that will be stored in the MovieTree BST
MovieNode* getMovieNode(int rank, string t, int y, float r) {
    MovieNode* nn = new MovieNode;
    nn->title = t;
    nn->ranking = rank;
    nn->year = y;
    nn->rating = r;
    return nn;
}

MovieTree::MovieTree() {
  root = NULL;
}

void deleteNode(MovieNode* node){
  if (node == NULL){
    return;
   
  }
  
  deleteNode(node -> right);
   deleteNode(node -> left);
    delete node;
}

MovieTree::~MovieTree() {
  deleteNode(root);
  root = NULL;
}


void helpPrintDatThang (MovieNode *m){
  if (m == NULL){
    

    return;
    
  }
  
   if (m->left != NULL) {
    helpPrintDatThang(m->left);
  }
cout << "Movie: " << m-> title << " " << "(" <<m-> rating << ")" << endl;
  if (m->right != NULL) {
    helpPrintDatThang(m->right);
  
}
  
  
}


void MovieTree::printMovieInventory() {

if (root == NULL){
    cout << "Tree is Empty. Cannot print." << endl;

}
   helpPrintDatThang(root);
}


MovieNode* makeIt(int ranking, string title, int year, float rating){
  MovieNode * temp = new MovieNode;
  temp -> ranking = ranking;
  temp -> title = title;
  temp -> year = year;
  temp -> rating = rating;
  temp -> left = NULL;
  temp -> right = NULL;
  //cout << "hey";
  return temp;
  
}

MovieNode* addItIn(MovieNode *m, int ranking, string title, int year, float rating){
  
  //MovieNode *crea = makeIt(ranking, title, year, rating);
  
  if (m == NULL){
  //cout << "hi";
   return makeIt(ranking, title, year, rating);
  }
  
  else if (m-> title > title){
    m-> left = addItIn(m-> left, ranking, title, year, rating);
    
    
  }
  
  else if (m->title < title){
      m-> right = addItIn(m-> right, ranking, title, year, rating);
  }
  return m;
  
  
}



void MovieTree::addMovieNode(int ranking, string title, int year, float rating) {
  MovieNode *m = root;
  root = addItIn(root, ranking, title, year, rating);
  
  
}

void netflixChill (string title, MovieNode * m){
  
  if (m == NULL){
    cout << "Movie not found." << endl;
    return;
    
  }
  
  if (m->title == title){
    cout << "Movie Info:" << endl;
    cout << "==================" << endl;
    cout << "Ranking:" << m->ranking << endl;
    cout << "Title :" << m->title << endl;
    cout << "Year :" << m->year << endl;
    cout << "rating :" << m->rating << endl;
  }
  
  else if (m-> title > title){
    netflixChill(title, m-> left);
    
    
  }
  
  else if (m->title < title){
     netflixChill(title, m-> right);
  }
 
  
  
  
}

void MovieTree::findMovie(string title) {
  netflixChill(title, root);
}

void sql(float rating, int year, MovieNode * m){
  if (m == NULL){
    return;
    
  }
  

  if (m-> year > year && m-> rating >= rating){
    
     cout << m->title << " " <<"(" << m->year << ") " << m->rating << endl;
  }
  
  sql(rating, year, m->left);
  sql(rating, year, m->right);
  
  
}
void MovieTree::queryMovies(float rating, int year) {
  cout << "Movies that came out after " << year << " with rating at least " << rating << ":" << endl;
  sql (rating, year, root);
}

int prettyAvgNod (MovieNode *m){
  
  if (m == NULL){
    return 0;
  }
  
  else if (m != NULL){
    return prettyAvgNod(m-> left) + prettyAvgNod(m-> right)+1;
    
  }
  
}

float prettyAvgRat (MovieNode *m){
  
  if (m == NULL){
    return 0;
    
  }
  
  else {
    return m-> rating + prettyAvgRat(m-> left) + prettyAvgRat(m-> right);
  }
  
  
}

void MovieTree::averageRating() {
  
  int totalMovies = prettyAvgNod(root);
  float totalRatings = prettyAvgRat(root);
  if (root == NULL){
    
    cout << "Average rating:0.0" << endl;
    
  }
  
  
  else {
    
    float average;
    average = totalRatings/ (totalMovies * 1.0);
    cout << "Average rating:" << average << endl;
    
  }
  
}


void levhelp (int level, MovieNode *lev){
  if (level < 0 || lev == NULL){
    return;
    
  }
  
  if (level == 0){
    
        cout<< "Movie: "<<lev->title<<" " << "(" << lev->rating << ")" <<endl;
  }
  
  else {
    
    
    levhelp(level-1, lev ->left);

    levhelp(level-1, lev ->right);
  }
  
  
}

void MovieTree::printLevelNodes(int level) {
  levhelp (level, root);
}